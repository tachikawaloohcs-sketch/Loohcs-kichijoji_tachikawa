"use server";

import { auth } from "@/auth";
import { prisma } from "@/lib/prisma";
import { revalidatePath } from "next/cache";

// ユーザー管理: 全ユーザー取得
export async function getUsers() {
    const session = await auth();
    if (session?.user?.role !== "ADMIN") return [];

    return await prisma.user.findMany({
        orderBy: { name: 'asc' },
        include: {
            _count: {
                select: { studentBookings: true, instructorShifts: true }
            }
        }
    });
}

// ユーザー管理: ステータス切り替え
export async function toggleUserStatus(userId: string) {
    const session = await auth();
    if (session?.user?.role !== "ADMIN") return { error: "Unauthorized" };

    if (userId === session.user.id) {
        return { error: "自分自身のステータスは変更できません" };
    }

    try {
        const user = await prisma.user.findUnique({ where: { id: userId } });
        if (!user) return { error: "User not found" };

        await prisma.user.update({
            where: { id: userId },
            data: { isActive: !user.isActive }
        });

        revalidatePath("/admin/dashboard");
        return { success: true };
    } catch (e) {
        return { error: "Failed to update user status" };
    }
}

// 授業管理: 全講師取得（シフト表示用）
export async function getAllInstructors() {
    const session = await auth();
    if (session?.user?.role !== "ADMIN") return [];

    return await prisma.user.findMany({
        where: { role: "INSTRUCTOR" },
        select: { id: true, name: true }
    });
}

// 授業管理: 全体シフト取得（カレンダー用）
export async function getMasterSchedule() {
    const session = await auth();
    if (session?.user?.role !== "ADMIN") return [];

    return await prisma.shift.findMany({
        where: {
            // For now, fetch all or maybe limit to recent/future?
            // Let's fetch +/- 3 months or just all for simplicity first
            start: {
                gte: new Date(new Date().setMonth(new Date().getMonth() - 1)) // From 1 month ago
            }
        },
        include: {
            instructor: { select: { name: true } },
            bookings: {
                include: {
                    student: { select: { name: true } }
                }
            }
        },
        orderBy: { start: 'asc' }
    });
}


// 授業管理: 特権シフト作成（制限なし）
export async function adminCreateShift(instructorId: string, date: Date, time: string) {
    const session = await auth();
    if (session?.user?.role !== "ADMIN") return { error: "Unauthorized" };

    const [hours, minutes] = time.split(":").map(Number);
    const startDateTime = new Date(date);
    startDateTime.setHours(hours, minutes, 0, 0);
    const endDateTime = new Date(startDateTime);
    endDateTime.setHours(startDateTime.getHours() + 1); // Default 1 hour

    try {
        await prisma.shift.create({
            data: {
                instructorId,
                start: startDateTime,
                end: endDateTime,
                type: "INDIVIDUAL",
                isPublished: true,
                location: "ONLINE" // Default
            }
        });
        revalidatePath("/admin/dashboard");
        return { success: true };
    } catch (e) {
        return { error: "シフト作成に失敗しました" };
    }
}

// 授業管理: 特権シフト削除（予約があっても削除）
export async function adminDeleteShift(shiftId: string) {
    const session = await auth();
    if (session?.user?.role !== "ADMIN") return { error: "Unauthorized" };

    try {
        // Bookings are cascaded? Usually not by default in prisma unless configured but let's check or do manual delete
        // Schema doesn't specify cascade. Need to delete bookings first.

        await prisma.booking.deleteMany({
            where: { shiftId }
        });

        await prisma.shift.delete({
            where: { id: shiftId }
        });

        revalidatePath("/admin/dashboard");
        return { success: true };
    } catch (e) {
        console.error(e);
        return { error: "シフト削除に失敗しました" };
    }
}

// 授業管理: 特権予約作成（強制予約）
export async function adminCreateBooking(shiftId: string, studentId: string) {
    const session = await auth();
    if (session?.user?.role !== "ADMIN") return { error: "Unauthorized" };

    // Check if slot is already booked? Overwrite? or Add another booking (Group style)?
    // Assuming 1-on-1, should check if booked. If booked, maybe error or overwrite?
    // "limitless" implies overriding checks. But schema might have unique constraints?
    // User wants "regardless of deadlines". Doesn't say "regardless of capacity".
    // But forcing a booking suggests maybe fitting them in.
    // If shift is INDIVIDUAL, logic usually assumes 1 booking.
    // Let's first check if booked.

    const shift = await prisma.shift.findUnique({
        where: { id: shiftId },
        include: { bookings: { where: { status: "CONFIRMED" } } }
    });

    if (!shift) return { error: "Shift not found" };

    if (shift.type === "INDIVIDUAL" && shift.bookings.length > 0) {
        return { error: "既に予約が入っています" };
        // Or should we allow replacing? For now, error is safer. 
        // The user request "全授業追加や削除や授業の生徒追加を授業後や前の期限関係なしでできるようにしてほしい"
        // "Add student to lesson" -> implies booking a slot.
    }

    try {
        await prisma.booking.create({
            data: {
                shiftId,
                studentId,
                status: "CONFIRMED",
                meetingType: "ONLINE"
            }
        });
        revalidatePath("/admin/dashboard");
        return { success: true };
    } catch (e) {
        return { error: "予約作成に失敗しました" };
    }
}

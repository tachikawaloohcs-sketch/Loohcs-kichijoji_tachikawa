import { getInstructorShifts, getInstructorRequests, getStudentsForInstructor } from "./actions";
import InstructorDashboardClient from "./InstructorDashboardClient";
import { Button } from "@/components/ui/button";
import { logout } from "@/lib/actions";

export default async function InstructorDashboardPage() {
    const shifts = await getInstructorShifts();
    const requests = await getInstructorRequests();
    const students = await getStudentsForInstructor();

    return (
        <div className="p-8 space-y-8 max-w-5xl mx-auto">
            <header className="flex justify-between items-center border-b pb-4">
                <div>
                    <h1 className="text-3xl font-bold text-slate-900 dark:text-slate-100">講師ダッシュボード</h1>
                    <p className="text-muted-foreground">シフト管理と生徒カルテ</p>
                </div>
                <div className="flex gap-2">
                    <form action={logout}>
                        <Button variant="outline">ログアウト</Button>
                    </form>
                </div>
            </header>

            <InstructorDashboardClient initialShifts={shifts} initialRequests={requests} students={students} />
        </div>
    );
}

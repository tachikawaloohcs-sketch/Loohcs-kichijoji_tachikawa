import Link from "next/link";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";

export default function Home() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-50 to-slate-100 dark:from-slate-900 dark:to-slate-950 flex flex-col items-center justify-center p-4">
      <div className="max-w-3xl w-full space-y-8 text-center">
        <h1 className="text-4xl font-extrabold tracking-tight lg:text-5xl text-primary dark:text-blue-400">
          Loohcs志塾立川・吉祥寺校予約システム
        </h1>
        <p className="text-xl text-slate-600 dark:text-slate-400">
          ログインする役割を選択してください
        </p>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-8">
          <Card className="hover:shadow-lg transition-shadow cursor-pointer border-t-4 border-primary">
            <CardHeader>
              <CardTitle>生徒</CardTitle>
              <CardDescription>授業の予約・履歴確認</CardDescription>
            </CardHeader>
            <CardContent>
              <Link href="/student/dashboard">
                <Button className="w-full">生徒としてログイン</Button>
              </Link>
            </CardContent>
          </Card>

          <Card className="hover:shadow-lg transition-shadow cursor-pointer border-t-4 border-primary">
            <CardHeader>
              <CardTitle>講師</CardTitle>
              <CardDescription>シフト提出・授業報告</CardDescription>
            </CardHeader>
            <CardContent>
              <Link href="/instructor/dashboard">
                <Button className="w-full" variant="outline">講師としてログイン</Button>
              </Link>
            </CardContent>
          </Card>

          <Card className="hover:shadow-lg transition-shadow cursor-pointer border-t-4 border-primary">
            <CardHeader>
              <CardTitle>管理者</CardTitle>
              <CardDescription>ユーザー管理・請求</CardDescription>
            </CardHeader>
            <CardContent>
              <Link href="/admin/dashboard">
                <Button className="w-full" variant="secondary">管理者としてログイン</Button>
              </Link>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}

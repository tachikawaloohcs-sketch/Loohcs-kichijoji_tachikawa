"use client";

import { useState, useTransition, useMemo, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Calendar } from "@/components/ui/calendar";
import { format, isSameDay } from "date-fns";
import { ja } from "date-fns/locale";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import {
    Dialog,
    DialogContent,
    DialogDescription,
    DialogFooter,
    DialogHeader,
    DialogTitle,
} from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { createShift, submitReport, approveRequest, rejectRequest, deleteShift } from "./actions";

type ShiftType = "individual" | "group" | "special" | "beginner" | "trial";

interface Booking {
    id: string;
    status: string;
    student: { name: string | null };
    report: { id: string } | null;
}

interface Shift {
    id: string;
    start: Date;
    end: Date;
    type: string;
    className?: string | null;
    location?: string; // Add location to interface
    bookings: Booking[];
}

interface Request {
    id: string;
    student: { name: string | null; email: string };
    start: Date;
    end: Date;
    status: string;
}

interface Report {
    id: string;
    content: string;
    homework: string | null;
    feedback: string | null;
    logUrl: string | null;
}

interface StudentBooking {
    id: string;
    shift: {
        start: Date;
        instructor: { name: string | null };
    };
    report: Report | null;
}

interface Student {
    id: string;
    name: string | null;
    email: string;
    studentBookings: StudentBooking[];
}

export default function InstructorDashboardClient({ initialShifts, initialRequests, students }: { initialShifts: Shift[], initialRequests: Request[], students: Student[] }) {
    const [date, setDate] = useState<Date | undefined>(undefined);

    useEffect(() => {
        setDate(new Date());
    }, []);

    const [isDialogOpen, setIsDialogOpen] = useState(false);
    const [isPending, startTransition] = useTransition();
    const currentShifts = initialShifts;
    const [requests, setRequests] = useState<Request[]>(initialRequests);
    const [selectedStudent, setSelectedStudent] = useState<Student | null>(null);
    const [activeTab, setActiveTab] = useState("shifts");

    // Report Dialog State
    const [isReportDialogOpen, setIsReportDialogOpen] = useState(false);
    const [selectedBookingId, setSelectedBookingId] = useState<string | null>(null);

    // Shift Form State
    const [startTime, setStartTime] = useState("10:00");
    const [endTime, setEndTime] = useState("11:00");
    const [shiftType, setShiftType] = useState<ShiftType>("individual");
    const [location, setLocation] = useState("ONLINE");
    const [classNameInput, setClassNameInput] = useState("");

    const handleDateSelect = (selectedDate: Date | undefined) => {
        setDate(selectedDate);
        if (selectedDate) {
            setIsDialogOpen(true);
        }
    };

    const handleCreateShift = async () => {
        if (!date) return;
        const formData = new FormData();
        formData.append("date", format(date, "yyyy-MM-dd"));
        formData.append("startTime", startTime);
        formData.append("endTime", endTime);
        formData.append("type", shiftType);
        formData.append("location", location);
        if (classNameInput) formData.append("className", classNameInput);

        startTransition(async () => {
            const result = await createShift(formData);
            if (result.success) {
                setIsDialogOpen(false);
                setShiftType("individual");
                setLocation("ONLINE");
                setClassNameInput("");
            } else {
                alert(result.error);
            }
        });
    };

    const getDayShifts = (day: Date) => {
        return currentShifts.filter((s) => isSameDay(s.start, day));
    };

    const formatDate = (d: Date) => format(d, "yyyy/MM/dd HH:mm");
    const formatTime = (d: Date) => format(d, "HH:mm");

    const getLocationLabel = (loc?: string) => {
        switch (loc) {
            case 'KICHIJOJI': return '吉祥寺';
            case 'TACHIKAWA': return '立川';
            case 'ONLINE': return 'オンライン';
            default: return 'オンライン';
        }
    };

    // Filter for Today's Classes needing reports
    const todayClasses = useMemo(() => {
        const today = new Date();
        return currentShifts.filter(s =>
            isSameDay(s.start, today) &&
            s.bookings.length > 0
        );
    }, [currentShifts]);

    const openReportDialog = (bookingId: string) => {
        setSelectedBookingId(bookingId);
        setIsReportDialogOpen(true);
    };

    const handleSubmitReport = async (formData: FormData) => {
        if (!selectedBookingId) return;
        startTransition(async () => {
            const res = await submitReport(selectedBookingId, formData);
            if (res.success) {
                alert("カルテを提出しました");
                setIsReportDialogOpen(false);
            } else {
                alert(res.error);
            }
        });
    };

    const handleApproveRequest = async (requestId: string) => {
        if (!confirm("このリクエストを承認しますか？（シフトと予約が作成されます）")) return;
        startTransition(async () => {
            const res = await approveRequest(requestId);
            if (res.success) {
                alert("リクエストを承認しました");
                setRequests(prev => prev.filter(r => r.id !== requestId));
            } else {
                alert(res.error);
            }
        });
    };

    const handleRejectRequest = async (requestId: string) => {
        if (!confirm("このリクエストを却下しますか？")) return;
        startTransition(async () => {
            const res = await rejectRequest(requestId);
            if (res.success) {
                alert("リクエストを却下しました");
                setRequests(prev => prev.filter(r => r.id !== requestId));
            } else {
                alert(res.error);
            }
        });
    };

    return (
        <div className="space-y-6">
            <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
                <TabsList className="mb-4">
                    <TabsTrigger value="shifts">シフト・授業管理</TabsTrigger>
                    <TabsTrigger value="reports">生徒カルテ閲覧</TabsTrigger>
                </TabsList>

                <TabsContent value="shifts" className="grid grid-cols-1 md:grid-cols-3 gap-8">
                    {/* Left: Calendar & Shift Input */}
                    <div className="md:col-span-2 space-y-6">
                        {/* Report Alert Section for Today */}
                        {todayClasses.length > 0 && (
                            <Card className="border-orange-500 bg-orange-50 dark:bg-orange-950/20">
                                <CardHeader>
                                    <CardTitle className="text-orange-700 dark:text-orange-400">本日の授業・カルテ提出</CardTitle>
                                    <CardDescription>授業後、当日23:59までにカルテを提出してください。</CardDescription>
                                </CardHeader>
                                <CardContent className="space-y-4">
                                    {todayClasses.map(shift => (
                                        shift.bookings.filter(b => b.status === 'CONFIRMED').map(booking => (
                                            <div key={booking.id} className="flex justify-between items-center bg-white dark:bg-slate-900 p-4 rounded shadow-sm">
                                                <div>
                                                    <div className="font-bold">
                                                        {formatTime(shift.start)} - {formatTime(shift.end)}
                                                        <Badge variant="outline" className="ml-2">{getLocationLabel(shift.location)}</Badge>
                                                    </div>
                                                    <div>生徒: {booking.student.name}</div>
                                                    {shift.className && <div className="text-xs text-muted-foreground">{shift.className}</div>}
                                                </div>
                                                {booking.report ? (
                                                    <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">提出済み</Badge>
                                                ) : (
                                                    <Button size="sm" onClick={() => openReportDialog(booking.id)}>カルテを書く</Button>
                                                )}
                                            </div>
                                        ))
                                    ))}
                                </CardContent>
                            </Card>
                        )}

                        <Card>
                            <CardHeader>
                                <CardTitle>シフト管理</CardTitle>
                                <CardDescription>
                                    日付を選択してシフト時間を登録してください。「登録」を押すと即時公開されます。
                                </CardDescription>
                            </CardHeader>
                            <CardContent className="flex flex-col md:flex-row gap-8">
                                <div className="flex-1">
                                    <Calendar
                                        mode="single"
                                        selected={date}
                                        onSelect={handleDateSelect}
                                        className="rounded-md border shadow mx-auto"
                                    />
                                </div>
                                <div className="flex-1 space-y-4">
                                    <h3 className="font-semibold text-lg border-b pb-2">
                                        {date ? format(date, "yyyy年M月d日", { locale: ja }) : "日付を選択"} のシフト
                                    </h3>

                                    <div className="space-y-2">
                                        {date && getDayShifts(date).length === 0 ? (
                                            <p className="text-sm text-muted-foreground">シフトは登録されていません。</p>
                                        ) : (
                                            date && getDayShifts(date).map((shift) => (
                                                <div key={shift.id} className="flex flex-col p-3 bg-slate-100 dark:bg-slate-800 rounded-lg">
                                                    <div className="flex justify-between items-center mb-1">
                                                        <div className="flex items-center gap-2">
                                                            <Badge variant={shift.type === "INDIVIDUAL" ? "default" : shift.type === "GROUP" ? "secondary" : shift.type === "BEGINNER" ? "outline" : shift.type === "TRIAL" ? "default" : "destructive"}>
                                                                {shift.type === "INDIVIDUAL" ? "個別" : shift.type === "GROUP" ? "集団" : shift.type === "BEGINNER" ? "ビギナー" : shift.type === "TRIAL" ? "無料体験" : "特別"}
                                                            </Badge>
                                                            <span className="font-mono text-sm">{formatTime(shift.start)} - {formatTime(shift.end)}</span>
                                                        </div>
                                                        <span className="text-xs text-muted-foreground">{getLocationLabel(shift.location)}</span>
                                                    </div>
                                                    <div className="flex justify-between items-center mt-2">
                                                        {shift.bookings.length > 0 ? (
                                                            <span className="text-xs text-blue-600">予約あり: {shift.bookings[0].student.name}</span>
                                                        ) : (
                                                            <span className="text-xs text-muted-foreground">予約なし</span>
                                                        )}

                                                        {/* Delete Button Logic */}
                                                        {shift.bookings.filter(b => b.status === 'CONFIRMED').length === 0 &&
                                                            new Date(shift.start).getTime() - new Date().getTime() > 24 * 60 * 60 * 1000 && (
                                                                <Button
                                                                    variant="ghost"
                                                                    size="sm"
                                                                    className="h-6 text-red-500 hover:text-red-700 hover:bg-red-50"
                                                                    onClick={() => {
                                                                        if (confirm("このシフトを削除しますか？")) {
                                                                            startTransition(async () => {
                                                                                const res = await deleteShift(shift.id);
                                                                                if (!res.success) alert(res.error);
                                                                            });
                                                                        }
                                                                    }}
                                                                    disabled={isPending}
                                                                >
                                                                    削除
                                                                </Button>
                                                            )}
                                                    </div>
                                                </div>
                                            ))
                                        )}
                                    </div>
                                </div>
                            </CardContent>
                        </Card>
                    </div>

                    {/* Right: Summary & Requests */}
                    <div className="space-y-6">
                        <Card>
                            <CardHeader>
                                <CardTitle>今月の稼働状況</CardTitle>
                            </CardHeader>
                            <CardContent>
                                <div className="text-2xl font-bold">{currentShifts.length} コマ</div>
                                <p className="text-sm text-muted-foreground">登録済みシフト</p>
                            </CardContent>
                        </Card>

                        {/* Requests List */}
                        <Card>
                            <CardHeader>
                                <CardTitle>日程リクエスト</CardTitle>
                                <CardDescription>生徒からの個別日程相談</CardDescription>
                            </CardHeader>
                            <CardContent className="space-y-4">
                                {requests.length === 0 ? (
                                    <p className="text-sm text-muted-foreground">リクエストはありません</p>
                                ) : (
                                    requests.map(req => (
                                        <div key={req.id} className="p-3 border rounded bg-slate-50 dark:bg-slate-900 space-y-2">
                                            <div className="font-bold text-sm">{req.student.name}</div>
                                            <div className="text-sm">
                                                {format(req.start, "M/d HH:mm", { locale: ja })} - {format(req.end, "HH:mm")}
                                            </div>
                                            <div className="flex gap-2 justify-end">
                                                <Button size="sm" variant="outline" className="text-red-500 hover:text-red-700" onClick={() => handleRejectRequest(req.id)} disabled={isPending}>却下</Button>
                                                <Button size="sm" onClick={() => handleApproveRequest(req.id)} disabled={isPending}>承認</Button>
                                            </div>
                                        </div>
                                    ))
                                )}
                            </CardContent>
                        </Card>
                    </div>

                    {/* Shift Dialog */}
                    <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
                        <DialogContent>
                            <DialogHeader>
                                <DialogTitle>シフトを追加</DialogTitle>
                                <DialogDescription>
                                    {date && format(date, "yyyy年M月d日", { locale: ja })} のシフト詳細を入力してください。
                                </DialogDescription>
                            </DialogHeader>
                            <div className="grid gap-4 py-4">
                                <div className="grid grid-cols-4 items-center gap-4">
                                    <Label className="text-right">時間</Label>
                                    <div className="col-span-3 flex gap-2 items-center">
                                        <Input type="time" value={startTime} onChange={(e) => setStartTime(e.target.value)} className="w-24" />
                                        <span>~</span>
                                        <Input type="time" value={endTime} onChange={(e) => setEndTime(e.target.value)} className="w-24" />
                                    </div>
                                </div>
                                <div className="grid grid-cols-4 items-center gap-4">
                                    <Label className="text-right">場所</Label>
                                    <Select value={location} onValueChange={setLocation}>
                                        <SelectTrigger className="col-span-3">
                                            <SelectValue />
                                        </SelectTrigger>
                                        <SelectContent>
                                            <SelectItem value="ONLINE">オンライン</SelectItem>
                                            <SelectItem value="KICHIJOJI">吉祥寺校舎</SelectItem>
                                            <SelectItem value="TACHIKAWA">立川校舎</SelectItem>
                                        </SelectContent>
                                    </Select>
                                </div>
                                <div className="grid grid-cols-4 items-center gap-4">
                                    <Label className="text-right">種別</Label>
                                    <Select value={shiftType} onValueChange={(val: ShiftType) => setShiftType(val)}>
                                        <SelectTrigger className="col-span-3">
                                            <SelectValue />
                                        </SelectTrigger>
                                        <SelectContent>
                                            <SelectItem value="individual">個別指導</SelectItem>
                                            <SelectItem value="group">集団授業</SelectItem>
                                            <SelectItem value="beginner">ビギナー</SelectItem>
                                            <SelectItem value="trial">無料体験</SelectItem>
                                            <SelectItem value="special">特別パック</SelectItem>
                                        </SelectContent>
                                    </Select>
                                </div>
                                {shiftType !== "individual" && (
                                    <div className="grid grid-cols-4 items-center gap-4">
                                        <Label className="text-right">授業名</Label>
                                        <Input
                                            value={classNameInput}
                                            onChange={(e) => setClassNameInput(e.target.value)}
                                            placeholder="例: 中3英語特訓"
                                            className="col-span-3"
                                        />
                                    </div>
                                )}
                            </div>
                            <DialogFooter>
                                <Button variant="outline" onClick={() => setIsDialogOpen(false)}>キャンセル</Button>
                                <Button onClick={handleCreateShift} disabled={isPending}>公開する</Button>
                            </DialogFooter>
                        </DialogContent>
                    </Dialog>

                    {/* Report Dialog */}
                    <Dialog open={isReportDialogOpen} onOpenChange={setIsReportDialogOpen}>
                        <DialogContent className="max-w-2xl">
                            <DialogHeader>
                                <DialogTitle>授業カルテの入力</DialogTitle>
                                <DialogDescription>
                                    本日の授業の報告を行ってください。
                                </DialogDescription>
                            </DialogHeader>
                            <form action={handleSubmitReport}>
                                <div className="grid gap-4 py-4">
                                    <div className="space-y-2">
                                        <Label>本日の実施内容（所感含む正直な記録）</Label>
                                        <Textarea name="content" required placeholder="授業内容と生徒の様子..." className="h-24" />
                                    </div>
                                    <div className="space-y-2">
                                        <Label>該当ログURL</Label>
                                        <Input name="logUrl" placeholder="https://..." />
                                    </div>
                                    <div className="space-y-2">
                                        <Label>宿題</Label>
                                        <Input name="homework" placeholder="P.24-25, 単語テスト" />
                                    </div>
                                    <div className="space-y-2">
                                        <Label>生徒への申し送り事項</Label>
                                        <Textarea name="feedback" placeholder="次回までに復習しておくこと..." />
                                    </div>
                                </div>
                                <DialogFooter>
                                    <Button variant="outline" type="button" onClick={() => setIsReportDialogOpen(false)}>キャンセル</Button>
                                    <Button type="submit" disabled={isPending}>提出する</Button>
                                </DialogFooter>
                            </form>
                        </DialogContent>
                    </Dialog>
                </TabsContent>

                <TabsContent value="reports" className="space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                        {/* Student List */}
                        <Card className="md:col-span-1 h-fit">
                            <CardHeader>
                                <CardTitle>生徒一覧</CardTitle>
                                <CardDescription>生徒を選択して過去のカルテを閲覧</CardDescription>
                            </CardHeader>
                            <CardContent className="space-y-4">
                                {students.length === 0 ? (
                                    <p className="text-muted-foreground">生徒がいません</p>
                                ) : (
                                    students.map(student => (
                                        <div
                                            key={student.id}
                                            className={`flex items-center gap-4 p-3 rounded cursor-pointer hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors ${selectedStudent?.id === student.id ? 'bg-slate-100 dark:bg-slate-800' : ''}`}
                                            onClick={() => setSelectedStudent(student)}
                                        >
                                            <Avatar>
                                                <AvatarFallback>{student.name?.[0]}</AvatarFallback>
                                            </Avatar>
                                            <div>
                                                <div className="font-semibold">{student.name}</div>
                                                <div className="text-xs text-muted-foreground">{student.email}</div>
                                                <div className="text-xs text-blue-600 mt-1">カルテ数: {student.studentBookings.length}</div>
                                            </div>
                                        </div>
                                    ))
                                )}
                            </CardContent>
                        </Card>

                        {/* Report View */}
                        <div className="md:col-span-2 space-y-6">
                            {selectedStudent ? (
                                <>
                                    <h2 className="text-2xl font-bold">{selectedStudent.name} さんのカルテ一覧</h2>
                                    {selectedStudent.studentBookings.length === 0 ? (
                                        <Card>
                                            <CardContent className="p-6 text-center text-muted-foreground">
                                                提出されたカルテはありません。
                                            </CardContent>
                                        </Card>
                                    ) : (
                                        selectedStudent.studentBookings.map(booking => (
                                            booking.report && (
                                                <Card key={booking.id}>
                                                    <CardHeader>
                                                        <CardTitle className="text-lg flex justify-between">
                                                            <span>{formatDate(booking.shift.start)}</span>
                                                            <span className="text-base font-normal text-muted-foreground">講師: {booking.shift.instructor.name}</span>
                                                        </CardTitle>
                                                    </CardHeader>
                                                    <CardContent className="space-y-4">
                                                        <div>
                                                            <h4 className="font-semibold text-sm mb-1">実施内容・所感</h4>
                                                            <p className="text-sm bg-slate-50 dark:bg-slate-900 p-3 rounded whitespace-pre-wrap">{booking.report.content}</p>
                                                        </div>
                                                        <div className="grid grid-cols-2 gap-4">
                                                            <div>
                                                                <h4 className="font-semibold text-sm mb-1">宿題</h4>
                                                                <p className="text-sm">{booking.report.homework || "なし"}</p>
                                                            </div>
                                                            <div>
                                                                <h4 className="font-semibold text-sm mb-1">生徒へのFB</h4>
                                                                <p className="text-sm">{booking.report.feedback || "なし"}</p>
                                                            </div>
                                                        </div>
                                                        {booking.report.logUrl && (
                                                            <div>
                                                                <h4 className="font-semibold text-sm mb-1">ログURL</h4>
                                                                <a href={booking.report.logUrl} target="_blank" rel="noopener noreferrer" className="text-blue-600 underline text-sm">
                                                                    {booking.report.logUrl}
                                                                </a>
                                                            </div>
                                                        )}
                                                    </CardContent>
                                                </Card>
                                            )
                                        ))
                                    )}
                                </>
                            ) : (
                                <div className="flex items-center justify-center h-64 border-2 border-dashed rounded-lg text-muted-foreground">
                                    左のリストから生徒を選択してください
                                </div>
                            )}
                        </div>
                    </div>
                </TabsContent>
            </Tabs>

            {/* Shift Dialog */}
            <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
                <DialogContent>
                    <DialogHeader>
                        <DialogTitle>シフトを追加</DialogTitle>
                        <DialogDescription>
                            {date && format(date, "yyyy年M月d日", { locale: ja })} のシフト詳細を入力してください。
                        </DialogDescription>
                    </DialogHeader>
                    <div className="grid gap-4 py-4">
                        <div className="grid grid-cols-4 items-center gap-4">
                            <Label className="text-right">時間</Label>
                            <div className="col-span-3 flex gap-2 items-center">
                                <Input type="time" value={startTime} onChange={(e) => setStartTime(e.target.value)} className="w-24" />
                                <span>~</span>
                                <Input type="time" value={endTime} onChange={(e) => setEndTime(e.target.value)} className="w-24" />
                            </div>
                        </div>
                        <div className="grid grid-cols-4 items-center gap-4">
                            <Label className="text-right">場所</Label>
                            <Select value={location} onValueChange={setLocation}>
                                <SelectTrigger className="col-span-3">
                                    <SelectValue />
                                </SelectTrigger>
                                <SelectContent>
                                    <SelectItem value="ONLINE">オンライン</SelectItem>
                                    <SelectItem value="KICHIJOJI">吉祥寺校舎</SelectItem>
                                    <SelectItem value="TACHIKAWA">立川校舎</SelectItem>
                                </SelectContent>
                            </Select>
                        </div>
                        <div className="grid grid-cols-4 items-center gap-4">
                            <Label className="text-right">種別</Label>
                            <Select value={shiftType} onValueChange={(val: ShiftType) => setShiftType(val)}>
                                <SelectTrigger className="col-span-3">
                                    <SelectValue />
                                </SelectTrigger>
                                <SelectContent>
                                    <SelectItem value="individual">個別指導</SelectItem>
                                    <SelectItem value="group">集団授業</SelectItem>
                                    <SelectItem value="beginner">ビギナー</SelectItem>
                                    <SelectItem value="trial">無料体験</SelectItem>
                                    <SelectItem value="special">特別パック</SelectItem>
                                </SelectContent>
                            </Select>
                        </div>
                        {shiftType !== "individual" && (
                            <div className="grid grid-cols-4 items-center gap-4">
                                <Label className="text-right">授業名</Label>
                                <Input
                                    value={classNameInput}
                                    onChange={(e) => setClassNameInput(e.target.value)}
                                    placeholder="例: 中3英語特訓"
                                    className="col-span-3"
                                />
                            </div>
                        )}
                    </div>
                    <DialogFooter>
                        <Button variant="outline" onClick={() => setIsDialogOpen(false)}>キャンセル</Button>
                        <Button onClick={handleCreateShift} disabled={isPending}>公開する</Button>
                    </DialogFooter>
                </DialogContent>
            </Dialog>

            {/* Report Dialog */}
            <Dialog open={isReportDialogOpen} onOpenChange={setIsReportDialogOpen}>
                <DialogContent className="max-w-2xl">
                    <DialogHeader>
                        <DialogTitle>授業カルテの入力</DialogTitle>
                        <DialogDescription>
                            本日の授業の報告を行ってください。
                        </DialogDescription>
                    </DialogHeader>
                    <form action={handleSubmitReport}>
                        <div className="grid gap-4 py-4">
                            <div className="space-y-2">
                                <Label>本日の実施内容（所感含む正直な記録）</Label>
                                <Textarea name="content" required placeholder="授業内容と生徒の様子..." className="h-24" />
                            </div>
                            <div className="space-y-2">
                                <Label>該当ログURL</Label>
                                <Input name="logUrl" placeholder="https://..." />
                            </div>
                            <div className="space-y-2">
                                <Label>宿題</Label>
                                <Input name="homework" placeholder="P.24-25, 単語テスト" />
                            </div>
                            <div className="space-y-2">
                                <Label>生徒への申し送り事項</Label>
                                <Textarea name="feedback" placeholder="次回までに復習しておくこと..." />
                            </div>
                        </div>
                        <DialogFooter>
                            <Button variant="outline" type="button" onClick={() => setIsReportDialogOpen(false)}>キャンセル</Button>
                            <Button type="submit" disabled={isPending}>提出する</Button>
                        </DialogFooter>
                    </form>
                </DialogContent>
            </Dialog>
        </div>
    );
}

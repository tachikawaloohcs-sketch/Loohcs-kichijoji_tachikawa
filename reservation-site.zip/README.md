# Loohcs志塾立川・吉祥寺校 予約システム

Next.js (App Router), Prisma, NextAuth.js を使用した予約管理システムです。講師としてシフトを管理し、生徒として授業を予約することができます。管理者は全ユーザーと予約状況を管理できます。

## 機能
- **生徒**: 授業予約、予約履歴確認、講師への日程リクエスト
- **講師**: シフト管理、授業報告（カルテ）作成、リクエスト承認
- **管理者**: ユーザー管理、全予約・シフト管理、カルテ閲覧

## 技術スタック
- Framework: Next.js 15+
- Database: SQLite (開発用) / PostgreSQL (本番想定)
- ORM: Prisma
- Auth: NextAuth.js (v5)
- UI: Tailwind CSS, Shadcn UI

## 開発環境のセットアップ

1. リポジトリをクローンまたはダウンロードします。
2. 依存関係をインストールします。
   ```bash
   npm install
   ```
3. 環境変数ファイル `.env` を作成します（`.env.example` があれば参考に、なければ以下を設定）。
   ```env
   DATABASE_URL="file:./dev.db"
   AUTH_SECRET="your-secret-key" # `npx auth secret` で生成可能
   ```
4. データベースのマイグレーションを実行します。
   ```bash
   npx prisma migrate dev --name init
   ```
5. 開発サーバーを起動します。
   ```bash
   npm run dev
   ```

## GitHubへのアップロード手順

このプロジェクトをGitHubで公開するための手順です。

1. [GitHub](https://github.com/new) で新しいリポジトリを作成します（Public または Private）。
2. ローカルでGitを初期化し、コミットします。
   ```bash
   git init
   git add .
   git commit -m "First commit"
   ```
3. GitHubのリポジトリをリモートとして追加し、プッシュします。
   ```bash
   git branch -M main
   git remote add origin https://github.com/YOUR_USERNAME/YOUR_REPO_NAME.git
   git push -u origin main
   ```

## Vercelへのデプロイ手順

本番環境（Vercel）で動作させる場合、SQLiteは使用できないため、PostgreSQL（Vercel PostgresやSupabaseなど）を使用する必要があります。

1. **GitHubリポジトリをVercelにインポート**します。
2. **データベースの準備**:
   - VercelのStorageタブから「Vercel Postgres」を作成するか、Supabase等でPostgreSQLデータベースを作成します。
   - 接続文字列（ConnectionString）を取得します。
3. **環境変数の設定**:
   - VercelのProject Settings > Environment Variables で以下を設定します。
     - `DATABASE_URL`: 取得したPostgreSQLの接続文字列（`postgres://...`）
     - `AUTH_SECRET`: 安全なランダム文字列
     - `AUTH_url`: 本番環境のURL（例: `https://your-project.vercel.app`）
4. **Build Commandの確認**:
   - Framework PresetがNext.jsになっていることを確認します。
   - Build Commandはデフォルトの `next build` で問題ありませんが、Prismaの生成を含めるために `npx prisma generate && next build` とすることもあります（通常は自動で検出されます）。
5. **デプロイ実行**:
   - デプロイが開始されると、自動的にビルドとデプロイが行われます。

### 注意点: データベースの変更
開発環境では `sqlite` を使用していますが、本番環境でPostgreSQLを使う場合、`prisma/schema.prisma` の `datasource` を変更する必要があります。

**デプロイ前に `prisma/schema.prisma` を以下のように変更してGitHubにプッシュしてください:**

```prisma
datasource db {
  provider = "postgresql" // "sqlite" から変更
  url      = env("DATABASE_URL")
}
```

※ PostgreSQLに変更した後、ローカルで動作確認する場合はローカルにもPostgreSQL環境が必要です。もしくは、環境変数で切り替える構成にする必要があります。

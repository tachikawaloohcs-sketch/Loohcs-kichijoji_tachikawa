"use client";

import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { format } from "date-fns";

interface Report {
    id: string;
    content: string;
    homework: string | null;
    feedback: string | null;
    logUrl: string | null;
}

interface Booking {
    id: string;
    shift: {
        start: Date;
        instructor: { name: string | null };
    };
    report: Report | null;
}

interface Student {
    id: string;
    name: string | null;
    email: string;
    studentBookings: Booking[];
}

interface CarteViewerProps {
    students: Student[];
}

export function CarteViewer({ students }: CarteViewerProps) {
    const [selectedStudent, setSelectedStudent] = useState<Student | null>(null);

    const formatDate = (d: Date) => format(new Date(d), "yyyy/MM/dd HH:mm");

    return (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {/* Student List */}
            <Card className="md:col-span-1 h-fit">
                <CardHeader>
                    <CardTitle>生徒一覧</CardTitle>
                    <CardDescription>生徒を選択して過去のカルテを閲覧</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                    {students.length === 0 ? (
                        <p className="text-muted-foreground">生徒がいません</p>
                    ) : (
                        students.map(student => (
                            <div
                                key={student.id}
                                className={`flex items-center gap-4 p-3 rounded cursor-pointer hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors ${selectedStudent?.id === student.id ? 'bg-slate-100 dark:bg-slate-800' : ''}`}
                                onClick={() => setSelectedStudent(student)}
                            >
                                <Avatar>
                                    <AvatarFallback>{student.name?.[0]}</AvatarFallback>
                                </Avatar>
                                <div>
                                    <div className="font-semibold">{student.name}</div>
                                    <div className="text-xs text-muted-foreground">{student.email}</div>
                                    <div className="text-xs text-blue-600 mt-1">カルテ数: {student.studentBookings.length}</div>
                                </div>
                            </div>
                        ))
                    )}
                </CardContent>
            </Card>

            {/* Report View */}
            <div className="md:col-span-2 space-y-6">
                {selectedStudent ? (
                    <>
                        <h2 className="text-2xl font-bold">{selectedStudent.name} さんのカルテ一覧</h2>
                        {selectedStudent.studentBookings.length === 0 ? (
                            <Card>
                                <CardContent className="p-6 text-center text-muted-foreground">
                                    提出されたカルテはありません。
                                </CardContent>
                            </Card>
                        ) : (
                            selectedStudent.studentBookings.map(booking => (
                                booking.report && (
                                    <Card key={booking.id}>
                                        <CardHeader>
                                            <CardTitle className="text-lg flex justify-between">
                                                <span>{formatDate(booking.shift.start)}</span>
                                                <span className="text-base font-normal text-muted-foreground">講師: {booking.shift.instructor.name}</span>
                                            </CardTitle>
                                        </CardHeader>
                                        <CardContent className="space-y-4">
                                            <div>
                                                <h4 className="font-semibold text-sm mb-1">実施内容・所感</h4>
                                                <p className="text-sm bg-slate-50 dark:bg-slate-900 p-3 rounded whitespace-pre-wrap">{booking.report.content}</p>
                                            </div>
                                            <div className="grid grid-cols-2 gap-4">
                                                <div>
                                                    <h4 className="font-semibold text-sm mb-1">宿題</h4>
                                                    <p className="text-sm">{booking.report.homework || "なし"}</p>
                                                </div>
                                                <div>
                                                    <h4 className="font-semibold text-sm mb-1">生徒へのFB</h4>
                                                    <p className="text-sm">{booking.report.feedback || "なし"}</p>
                                                </div>
                                            </div>
                                            {booking.report.logUrl && (
                                                <div>
                                                    <h4 className="font-semibold text-sm mb-1">ログURL</h4>
                                                    <a href={booking.report.logUrl} target="_blank" rel="noopener noreferrer" className="text-blue-600 underline text-sm">
                                                        {booking.report.logUrl}
                                                    </a>
                                                </div>
                                            )}
                                        </CardContent>
                                    </Card>
                                )
                            ))
                        )}
                    </>
                ) : (
                    <div className="flex items-center justify-center h-64 border-2 border-dashed rounded-lg text-muted-foreground">
                        左のリストから生徒を選択してください
                    </div>
                )}
            </div>
        </div>
    );
}

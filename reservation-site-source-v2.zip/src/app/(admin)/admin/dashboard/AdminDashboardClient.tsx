"use client";

import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { format, isSameDay } from "date-fns";
import { ja } from "date-fns/locale";
import { Calendar } from "@/components/ui/calendar";
import { Badge } from "@/components/ui/badge";

interface Report {
    id: string;
    content: string;
    homework: string | null;
    feedback: string | null;
    logUrl: string | null;
}

interface User {
    id: string;
    name: string | null;
    email: string;
    role: string;
    isActive: boolean;
    _count?: {
        studentBookings: number;
        instructorShifts: number;
    };
}

interface Instructor {
    id: string;
    name: string | null;
}

interface Booking {
    id: string;
    shift: {
        start: Date;
        instructor: { name: string | null };
    };
    report: Report | null;
}

interface Student {
    id: string;
    name: string | null;
    email: string;
    studentBookings: Booking[];
}

interface Shift {
    id: string;
    start: Date;
    end: Date;
    type: string;
    instructor: { name: string | null };
    bookings: { student: { name: string | null } }[];
    location: string;
    className?: string | null;
}

import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { toggleUserStatus, adminCreateShift, adminCreateBooking, adminDeleteShift } from "./actions";

export default function AdminDashboardClient({ students, allUsers, allInstructors, masterShifts }: { students: Student[], allUsers: User[], allInstructors: Instructor[], masterShifts: Shift[] }) {
    const [selectedStudent, setSelectedStudent] = useState<Student | null>(null);
    const [activeTab, setActiveTab] = useState("reports");
    const [calendarDate, setCalendarDate] = useState<Date | undefined>(undefined);
    useEffect(() => {
        setCalendarDate(new Date());
    }, []);

    // Lesson Management State
    const [shiftInstructorId, setShiftInstructorId] = useState("");
    const [shiftDate, setShiftDate] = useState<Date | undefined>(undefined);
    useEffect(() => {
        setShiftDate(new Date());
    }, []);
    const [shiftTime, setShiftTime] = useState("10:00");

    const [bookingShiftId, setBookingShiftId] = useState("");
    const [bookingStudentId, setBookingStudentId] = useState("");

    // Schedule Filters
    const [filterInstructor, setFilterInstructor] = useState("ALL");
    const [filterLocation, setFilterLocation] = useState("ALL");
    const [filterType, setFilterType] = useState("ALL");

    const filteredShifts = masterShifts.filter(shift => {
        if (filterInstructor !== "ALL" && shift.instructor.name !== filterInstructor) return false;
        if (filterLocation !== "ALL" && shift.location !== filterLocation) return false;
        if (filterType !== "ALL" && shift.type !== filterType) return false;
        return true;
    });

    const handleToggleStatus = async (userId: string) => {
        if (!confirm("ユーザーのステータスを変更しますか？")) return;
        const res = await toggleUserStatus(userId);
        if (!res.success) alert(res.error);
    };

    const handleCreateShift = async () => {
        if (!shiftInstructorId) return alert("講師を選択してください");
        if (!shiftDate) return alert("日付を選択してください");
        const res = await adminCreateShift(shiftInstructorId, shiftDate, shiftTime);
        if (res.success) alert("シフトを作成しました");
        else alert(res.error);
    };

    const handleCreateBooking = async () => {
        if (!bookingShiftId || !bookingStudentId) return alert("シフトIDと生徒IDを入力してください");
        const res = await adminCreateBooking(bookingShiftId, bookingStudentId);
        if (res.success) alert("予約を作成しました（強制）");
        else alert(res.error);
    };

    const formatDate = (d: Date) => format(d, "yyyy/MM/dd HH:mm");

    return (
        <div className="container mx-auto p-6 space-y-8">
            <header className="flex justify-between items-center mb-8">
                <div>
                    <h1 className="text-3xl font-bold">管理者ダッシュボード</h1>
                    <p className="text-muted-foreground">生徒のカルテ管理</p>
                </div>
            </header>

            <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
                <TabsList>
                    <TabsTrigger value="reports">カルテ管理</TabsTrigger>
                    <TabsTrigger value="master-schedule">全体スケジュール</TabsTrigger>
                    <TabsTrigger value="users">ユーザー管理</TabsTrigger>
                    <TabsTrigger value="lessons">授業管理（特権）</TabsTrigger>
                </TabsList>

                <TabsContent value="reports" className="space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                        {/* Student List */}
                        <Card className="md:col-span-1 h-fit">
                            <CardHeader>
                                <CardTitle>生徒一覧</CardTitle>
                                <CardDescription>カルテを確認したい生徒を選択してください</CardDescription>
                            </CardHeader>
                            <CardContent className="space-y-4">
                                {students.length === 0 ? (
                                    <p className="text-muted-foreground">生徒がいません</p>
                                ) : (
                                    students.map(student => (
                                        <div
                                            key={student.id}
                                            className={`flex items-center gap-4 p-3 rounded cursor-pointer hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors ${selectedStudent?.id === student.id ? 'bg-slate-100 dark:bg-slate-800' : ''}`}
                                            onClick={() => setSelectedStudent(student)}
                                        >
                                            <Avatar>
                                                <AvatarFallback>{student.name?.[0]}</AvatarFallback>
                                            </Avatar>
                                            <div>
                                                <div className="font-semibold">{student.name}</div>
                                                <div className="text-xs text-muted-foreground">{student.email}</div>
                                                <div className="text-xs text-blue-600 mt-1">カルテ数: {student.studentBookings.length}</div>
                                            </div>
                                        </div>
                                    ))
                                )}
                            </CardContent>
                        </Card>

                        {/* Report View */}
                        <div className="md:col-span-2 space-y-6">
                            {selectedStudent ? (
                                <>
                                    <h2 className="text-2xl font-bold">{selectedStudent.name} さんのカルテ一覧</h2>
                                    {selectedStudent.studentBookings.length === 0 ? (
                                        <Card>
                                            <CardContent className="p-6 text-center text-muted-foreground">
                                                提出されたカルテはありません。
                                            </CardContent>
                                        </Card>
                                    ) : (
                                        selectedStudent.studentBookings.map(booking => (
                                            booking.report && (
                                                <Card key={booking.id}>
                                                    <CardHeader>
                                                        <CardTitle className="text-lg flex justify-between">
                                                            <span>{formatDate(booking.shift.start)}</span>
                                                            <span className="text-base font-normal text-muted-foreground">講師: {booking.shift.instructor.name}</span>
                                                        </CardTitle>
                                                    </CardHeader>
                                                    <CardContent className="space-y-4">
                                                        <div>
                                                            <h4 className="font-semibold text-sm mb-1">実施内容・所感</h4>
                                                            <p className="text-sm bg-slate-50 dark:bg-slate-900 p-3 rounded whitespace-pre-wrap">{booking.report.content}</p>
                                                        </div>
                                                        <div className="grid grid-cols-2 gap-4">
                                                            <div>
                                                                <h4 className="font-semibold text-sm mb-1">宿題</h4>
                                                                <p className="text-sm">{booking.report.homework || "なし"}</p>
                                                            </div>
                                                            <div>
                                                                <h4 className="font-semibold text-sm mb-1">生徒へのFB</h4>
                                                                <p className="text-sm">{booking.report.feedback || "なし"}</p>
                                                            </div>
                                                        </div>
                                                        {booking.report.logUrl && (
                                                            <div>
                                                                <h4 className="font-semibold text-sm mb-1">ログURL</h4>
                                                                <a href={booking.report.logUrl} target="_blank" rel="noopener noreferrer" className="text-blue-600 underline text-sm">
                                                                    {booking.report.logUrl}
                                                                </a>
                                                            </div>
                                                        )}
                                                    </CardContent>
                                                </Card>
                                            )
                                        ))
                                    )}
                                </>
                            ) : (
                                <div className="flex items-center justify-center h-64 border-2 border-dashed rounded-lg text-muted-foreground">
                                    左のリストから生徒を選択してください
                                </div>
                            )}
                        </div>
                    </div>
                </TabsContent>

                <TabsContent value="master-schedule" className="space-y-6">
                    <Card>
                        <CardHeader>
                            <CardTitle>全体スケジュール</CardTitle>
                            <CardDescription>全講師のシフト状況（登録数: {masterShifts.length}）</CardDescription>
                        </CardHeader>
                        <CardContent className="flex flex-col gap-6">
                            {/* Filters */}
                            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 p-4 bg-muted/50 rounded-lg">
                                <div className="space-y-2">
                                    <Label>講師で絞り込み</Label>
                                    <Select value={filterInstructor} onValueChange={setFilterInstructor}>
                                        <SelectTrigger>
                                            <SelectValue placeholder="全講師" />
                                        </SelectTrigger>
                                        <SelectContent>
                                            <SelectItem value="ALL">全講師</SelectItem>
                                            {allInstructors.map(inst => (
                                                <SelectItem key={inst.id} value={inst.name || "Unknown"}>{inst.name}</SelectItem>
                                            ))}
                                        </SelectContent>
                                    </Select>
                                </div>
                                <div className="space-y-2">
                                    <Label>場所で絞り込み</Label>
                                    <Select value={filterLocation} onValueChange={setFilterLocation}>
                                        <SelectTrigger>
                                            <SelectValue placeholder="全場所" />
                                        </SelectTrigger>
                                        <SelectContent>
                                            <SelectItem value="ALL">全場所</SelectItem>
                                            <SelectItem value="ONLINE">オンライン</SelectItem>
                                            <SelectItem value="KICHIJOJI">吉祥寺</SelectItem>
                                            <SelectItem value="TACHIKAWA">立川</SelectItem>
                                        </SelectContent>
                                    </Select>
                                </div>
                                <div className="space-y-2">
                                    <Label>授業種類で絞り込み</Label>
                                    <Select value={filterType} onValueChange={setFilterType}>
                                        <SelectTrigger>
                                            <SelectValue placeholder="全種類" />
                                        </SelectTrigger>
                                        <SelectContent>
                                            <SelectItem value="ALL">全種類</SelectItem>
                                            <SelectItem value="INDIVIDUAL">個別</SelectItem>
                                            <SelectItem value="GROUP">集団</SelectItem>
                                            <SelectItem value="BEGINNER">ビギナー</SelectItem>
                                            <SelectItem value="TRIAL">無料体験</SelectItem>
                                            <SelectItem value="SPECIAL">特別</SelectItem>
                                        </SelectContent>
                                    </Select>
                                </div>
                            </div>

                            <div className="flex flex-col md:flex-row gap-8">
                                <div className="flex-1">
                                    <Calendar
                                        mode="single"
                                        selected={calendarDate}
                                        onSelect={setCalendarDate}
                                        className="rounded-md border shadow mx-auto"
                                    />
                                </div>
                                <div className="flex-1 space-y-4">
                                    <h3 className="font-semibold text-lg border-b pb-2">
                                        {calendarDate ? format(calendarDate, "yyyy年M月d日", { locale: ja }) : "日付を選択"} のシフト
                                    </h3>
                                    <div className="space-y-2">
                                        {calendarDate && filteredShifts.filter(s => isSameDay(s.start, calendarDate)).length === 0 ? (
                                            <p className="text-sm text-muted-foreground">シフトはありません。</p>
                                        ) : (
                                            calendarDate && filteredShifts.filter(s => isSameDay(s.start, calendarDate)).map((shift) => (
                                                <div key={shift.id} className="flex flex-col p-3 bg-slate-100 dark:bg-slate-800 rounded-lg text-sm">
                                                    <div className="flex justify-between items-center mb-1">
                                                        <div className="font-bold text-blue-700 dark:text-blue-300">
                                                            {shift.instructor.name}
                                                        </div>
                                                        <div className="flex gap-2">
                                                            <Badge variant="outline">{shift.location === 'ONLINE' ? 'オンライン' : shift.location === 'KICHIJOJI' ? '吉祥寺' : '立川'}</Badge>
                                                            <Button
                                                                variant="destructive"
                                                                size="sm"
                                                                className="h-6 text-[10px] px-2"
                                                                onClick={async () => {
                                                                    if (!confirm("本当にこのシフトを削除しますか？\n（予約がある場合、予約も削除されます）")) return;
                                                                    const res = await adminDeleteShift(shift.id);
                                                                    if (res.success) alert("削除しました");
                                                                    else alert(res.error);
                                                                }}
                                                            >
                                                                削除
                                                            </Button>
                                                        </div>
                                                    </div>
                                                    <div className="flex items-center gap-2 mb-1">
                                                        <span>{format(shift.start, "HH:mm")} - {format(shift.end, "HH:mm")}</span>
                                                        <Badge variant={shift.type === "INDIVIDUAL" ? "default" : shift.type === "GROUP" ? "secondary" : shift.type === "BEGINNER" ? "outline" : shift.type === "TRIAL" ? "default" : "destructive"} className="text-[10px]">
                                                            {shift.type === "INDIVIDUAL" ? "個別" : shift.type === "GROUP" ? "集団" : shift.type === "BEGINNER" ? "ビギナー" : shift.type === "TRIAL" ? "無料体験" : "特別"}
                                                        </Badge>
                                                    </div>
                                                    {shift.className && <div className="text-xs text-muted-foreground mb-1">{shift.className}</div>}
                                                    <div className="text-xs">
                                                        {shift.bookings.length > 0 ? (
                                                            <span className="text-green-600 font-semibold">予約: {shift.bookings[0].student.name}</span>
                                                        ) : (
                                                            <span className="text-muted-foreground">予約なし</span>
                                                        )}
                                                    </div>
                                                </div>
                                            ))
                                        )}
                                    </div>
                                </div>
                            </div>
                        </CardContent>
                    </Card>
                </TabsContent>

                <TabsContent value="users">
                    <Card>
                        <CardHeader>
                            <CardTitle>ユーザー管理</CardTitle>
                            <CardDescription>ユーザーの有効化・無効化（停止）を行います。</CardDescription>
                        </CardHeader>
                        <CardContent>
                            <div className="rounded-md border">
                                <table className="min-w-full text-sm">
                                    <thead>
                                        <tr className="border-b bg-muted/50">
                                            <th className="p-4 text-left font-medium">名前</th>
                                            <th className="p-4 text-left font-medium">メールアドレス</th>
                                            <th className="p-4 text-left font-medium">権限</th>
                                            <th className="p-4 text-left font-medium">状態</th>
                                            <th className="p-4 text-left font-medium">操作</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        {allUsers.map((user) => (
                                            <tr key={user.id} className="border-b transition-colors hover:bg-muted/50">
                                                <td className="p-4">{user.name}</td>
                                                <td className="p-4">{user.email}</td>
                                                <td className="p-4">{user.role}</td>
                                                <td className="p-4">
                                                    <span className={`inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-semibold ${user.isActive ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}`}>
                                                        {user.isActive ? '有効' : '停止中'}
                                                    </span>
                                                </td>
                                                <td className="p-4">
                                                    <Button variant={user.isActive ? "destructive" : "outline"} size="sm" onClick={() => handleToggleStatus(user.id)}>
                                                        {user.isActive ? '停止する' : '有効にする'}
                                                    </Button>
                                                </td>
                                            </tr>
                                        ))}
                                    </tbody>
                                </table>
                            </div>
                        </CardContent>
                    </Card>
                </TabsContent>

                <TabsContent value="lessons" className="space-y-6">
                    <Card>
                        <CardHeader>
                            <CardTitle>特権シフト作成</CardTitle>
                            <CardDescription>制限（時間、重複など）を無視してシフトを作成します。</CardDescription>
                        </CardHeader>
                        <CardContent className="space-y-4">
                            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                                <div className="space-y-2">
                                    <Label>講師</Label>
                                    <Select onValueChange={setShiftInstructorId}>
                                        <SelectTrigger>
                                            <SelectValue placeholder="講師を選択" />
                                        </SelectTrigger>
                                        <SelectContent>
                                            {allInstructors.map(inst => (
                                                <SelectItem key={inst.id} value={inst.id}>{inst.name}</SelectItem>
                                            ))}
                                        </SelectContent>
                                    </Select>
                                </div>
                                <div className="space-y-2">
                                    <Label>日付</Label>
                                    <Input type="date" onChange={(e) => setShiftDate(new Date(e.target.value))} />
                                </div>
                                <div className="space-y-2">
                                    <Label>開始時間</Label>
                                    <Input type="time" value={shiftTime} onChange={(e) => setShiftTime(e.target.value)} />
                                </div>
                            </div>
                            <Button onClick={handleCreateShift}>シフト作成（強制）</Button>
                        </CardContent>
                    </Card>

                    <Card>
                        <CardHeader>
                            <CardTitle>特権予約作成</CardTitle>
                            <CardDescription>任意のシフトに任意の生徒を強制予約します。</CardDescription>
                        </CardHeader>
                        <CardContent className="space-y-4">
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                <div className="space-y-2">
                                    <Label>シフトID</Label>
                                    <Input placeholder="Shift ID" value={bookingShiftId} onChange={(e) => setBookingShiftId(e.target.value)} />
                                    <p className="text-xs text-muted-foreground">※ シフトIDはDB等から確認してください（簡易実装）</p>
                                </div>
                                <div className="space-y-2">
                                    <Label>生徒ID</Label>
                                    <Input placeholder="Student ID" value={bookingStudentId} onChange={(e) => setBookingStudentId(e.target.value)} />
                                </div>
                            </div>
                            <Button onClick={handleCreateBooking}>予約作成（強制）</Button>
                        </CardContent>
                    </Card>
                </TabsContent>
            </Tabs>
        </div>
    );
}

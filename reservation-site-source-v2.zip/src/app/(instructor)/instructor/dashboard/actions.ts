"use server";

import { auth } from "@/auth";
import { prisma } from "@/lib/prisma";
import { revalidatePath } from "next/cache";
import { format } from "date-fns";
import { ja } from "date-fns/locale";

// Mock Email Function
async function sendEmail(to: string, subject: string, body: string) {
    console.log(`[EMAIL SIMULATION]`);
    console.log(`To: ${to}`);
    console.log(`Subject: ${subject}`);
    console.log(`Body: ${body}`);
    console.log(`-------------------`);
}

export async function getInstructorShifts() {
    const session = await auth();
    if (!session?.user?.id || session.user.role !== "INSTRUCTOR") {
        return [];
    }

    const shifts = await prisma.shift.findMany({
        where: {
            instructorId: session.user.id,
        },
        include: {
            bookings: {
                include: {
                    student: { select: { name: true } },
                    report: true
                }
            }
        },
        orderBy: {
            start: 'asc',
        },
    });

    return shifts;
}

export async function getInstructorRequests() {
    const session = await auth();
    if (!session?.user?.id || session.user.role !== "INSTRUCTOR") return [];

    return await prisma.scheduleRequest.findMany({
        where: {
            instructorId: session.user.id,
            status: "PENDING"
        },
        include: {
            student: { select: { name: true, email: true } }
        },
        orderBy: { createdAt: 'desc' }
    });
}

// New function for Report Management
export async function getStudentsForInstructor() {
    const session = await auth();
    if (session?.user?.role !== "INSTRUCTOR") return [];

    // Instructors should see all students to view their past reports history
    return await prisma.user.findMany({
        where: { role: "STUDENT" },
        include: {
            studentBookings: {
                include: {
                    shift: {
                        include: {
                            instructor: { select: { name: true } }
                        }
                    },
                    report: true
                },
                orderBy: { shift: { start: 'desc' } }
            }
        },
        orderBy: { name: 'asc' }
    });
}

export async function createShift(formData: FormData) {
    const session = await auth();
    if (!session?.user?.id || session.user.role !== "INSTRUCTOR") {
        return { error: "Unauthorized" };
    }

    const dateStr = formData.get("date") as string;
    const startTime = formData.get("startTime") as string;
    const endTime = formData.get("endTime") as string;
    const type = formData.get("type") as string;
    const className = formData.get("className") as string;

    if (!dateStr || !startTime || !endTime || !type) {
        return { error: "Missing fields" };
    }

    const startDateTime = new Date(`${dateStr}T${startTime}:00`);
    const endDateTime = new Date(`${dateStr}T${endTime}:00`);

    try {
        const shift = await prisma.shift.create({
            data: {
                instructorId: session.user.id,
                start: startDateTime,
                end: endDateTime,
                type: type.toUpperCase(),
                className: className || null,
                location: formData.get("location") as string || "ONLINE",
                isPublished: true,
            },
        });

        revalidatePath("/instructor/dashboard");
        return { success: true, shift };
    } catch {
        return { error: "Database error" };
    }
}

export async function submitReport(bookingId: string, formData: FormData) {
    const session = await auth();
    if (!session?.user?.id || session.user.role !== "INSTRUCTOR") {
        return { error: "Unauthorized" };
    }

    const content = formData.get("content") as string;
    const logUrl = formData.get("logUrl") as string;
    const homework = formData.get("homework") as string;
    const feedback = formData.get("feedback") as string;

    const booking = await prisma.booking.findUnique({
        where: { id: bookingId },
        include: { shift: true }
    });

    if (!booking) return { error: "Booking not found" };

    const now = new Date();
    const shiftStart = new Date(booking.shift.start);

    if (now < shiftStart) {
        return { error: "授業開始前です。まだカルテは記入できません。" };
    }

    const deadline = new Date(shiftStart);
    deadline.setHours(23, 59, 59, 999);

    if (now > deadline) {
        return { error: "提出期限切れです（当日23:59まで）。管理者に連絡してください。" };
    }

    try {
        await prisma.report.create({
            data: {
                bookingId: bookingId,
                content,
                logUrl,
                homework,
                feedback
            }
        });
        revalidatePath("/instructor/dashboard");
        return { success: true };
    } catch {
        return { error: "Failed to submit report" };
    }
}

export async function deleteShift(shiftId: string) {
    const session = await auth();
    if (!session?.user?.id || session.user.role !== "INSTRUCTOR") {
        return { error: "Unauthorized" };
    }

    const shift = await prisma.shift.findUnique({
        where: { id: shiftId },
        include: { bookings: true }
    });

    if (!shift) return { error: "Shift not found" };
    if (shift.instructorId !== session.user.id) return { error: "Not your shift" };

    const hasActiveBooking = shift.bookings.some(b => b.status === "CONFIRMED");
    if (hasActiveBooking) {
        return { error: "予約が入っているため削除できません。管理者に連絡してください。" };
    }

    const now = new Date();
    const shiftStart = new Date(shift.start);
    const timeDiff = shiftStart.getTime() - now.getTime();
    const hoursUntilStart = timeDiff / (1000 * 60 * 60);

    if (hoursUntilStart < 24) {
        return { error: "授業開始24時間前を切っているため削除できません。" };
    }

    try {
        await prisma.shift.delete({
            where: { id: shiftId }
        });
        revalidatePath("/instructor/dashboard");
        return { success: true };
    } catch {
        return { error: "Failed to delete shift" };
    }
}

export async function approveRequest(requestId: string) {
    const session = await auth();
    if (!session?.user?.id || session.user.role !== "INSTRUCTOR") return { error: "Unauthorized" };

    const request = await prisma.scheduleRequest.findUnique({
        where: { id: requestId },
        include: { student: true, instructor: true }
    });

    if (!request) return { error: "Request not found" };

    try {
        await prisma.$transaction(async (tx) => {
            const shift = await tx.shift.create({
                data: {
                    instructorId: session.user.id as string,
                    start: request.start,
                    end: request.end,
                    type: "INDIVIDUAL",
                    location: "ONLINE", // Defaulting to ONLINE as per plan
                    isPublished: true,
                }
            });

            await tx.booking.create({
                data: {
                    studentId: request.studentId,
                    shiftId: shift.id,
                    status: "CONFIRMED",
                    meetingType: "ONLINE"
                }
            });

            await tx.scheduleRequest.update({
                where: { id: requestId },
                data: { status: "APPROVED" }
            });
        });

        await sendEmail(
            request.student.email,
            "日程リクエストが承認されました",
            `${format(request.start, "MM/dd HH:mm", { locale: ja })} のリクエストが${request.instructor.name}講師により承認されました。`
        );

        revalidatePath("/instructor/dashboard");
        return { success: true };
    } catch (e) {
        console.error(e);
        return { error: "Failed to approve request" };
    }
}

export async function rejectRequest(requestId: string) {
    const session = await auth();
    if (!session?.user?.id || session.user.role !== "INSTRUCTOR") return { error: "Unauthorized" };

    const request = await prisma.scheduleRequest.findUnique({
        where: { id: requestId },
        include: { student: true }
    });

    if (!request) return { error: "Request not found" };

    try {
        await prisma.scheduleRequest.update({
            where: { id: requestId },
            data: { status: "REJECTED" }
        });

        await sendEmail(
            request.student.email,
            "日程リクエストが却下されました",
            `リクエストされた日程は都合により承認されませんでした。別の日程で再度ご検討ください。`
        );

        revalidatePath("/instructor/dashboard");
        return { success: true };
    } catch {
        return { error: "Failed to reject request" };
    }
}

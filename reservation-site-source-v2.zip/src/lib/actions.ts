"use server";

import { signIn, signOut } from "@/auth";
import { AuthError } from "next-auth";
import { prisma } from "@/lib/prisma";
import bcrypt from "bcryptjs";

export async function authenticate(prevState: string | undefined, formData: FormData) {
    try {
        await signIn("credentials", formData, { redirectTo: "/" });
    } catch (error) {
        if (error instanceof AuthError) {
            switch (error.type) {
                case "CredentialsSignin":
                    return "Invalid credentials.";
                default:
                    return "Something went wrong.";
            }
        }
        throw error;
    }
}

export async function register(prevState: string | undefined, formData: FormData) {
    const name = formData.get("name") as string;
    const email = formData.get("email") as string;
    const password = formData.get("password") as string;
    const role = formData.get("role") as string; // STUDENT, INSTRUCTOR, ADMIN

    if (!email || !password || !name) {
        return "Missing fields";
    }

    // Admin Registration Restriction
    if (role === "ADMIN") {
        if (email !== "tachikawa.loohcs@gmail.com") {
            return "このメールアドレスでは管理者登録できません";
        }
        if (password !== "Yamamoto_Hasegawa2525") {
            return "管理者パスワードが違います";
        }
    }

    try {
        const hashedPassword = await bcrypt.hash(password, 10);

        await prisma.user.create({
            data: {
                name,
                email,
                password: hashedPassword,
                role: role || "STUDENT",
            },
        });
    } catch {
        return "User already exists or database error";
    }

    return "success";
}

export async function logout() {
    await signOut();
}
